# Requires -Version 7.0
<#
    .SYNOPSIS
        ITC Secure - Mimecast to Sentinel log integration. 

    .DESCRIPTION
        Pulls the last 5 minutes work of the following logs from Mimecast leveraging the Mimecast API:
            URL Protection
            Impersonation Protection
            Attachment Protection
            Email logs
            Audit Logs
        The following permissions are required from Mimecast to collect logs for the above source:
            Monitoring | URL Protection | Read
            Monitoring | Impersonation Protection | Read
            Monitoring | Attachment Protection | Read
            Gateway | Tracking | Read
            Account | Logs | Read
            Enhanced Logging | Enable
        Mimecast logs are collected and parsed before being uploaded to Log Analytics as a custom log source. 
        Each separate log has a custom log source and table, which are the following:
            Mimecast_URL_Logs
            Mimecast_Attachment_Logs
            Mimecast_Impersonation_Logs
            Mimecast_Audit_Logs
            Mimecast_Email_Logs
        A connection to the Azure storage space is required to read and write data to a table within a storage space. 
        This table collects and imports a token collected from the Email logs API call, which is then used in the following call during the next script run.
        This connector requires the following information and configuration to run successfully:
            Log analytic workspace ID and Key
            Mimecast App ID, Access Key, Secret Key and App key
            Storage space Name and shared key
            Storage space table name, partition key and row key
        The following information is stored within the Azure function global variables and is then passed into this script.

        Custom functions have been created to connect, get and update data within the storage space table,
        Upload data to log analytics and get data from Mimecast log sources.
        
    .INPUTS
        Get-MimecastLogs requires a log type: URL, Attachment, Impersonation, Email or Audit. This is run the correct part of the custom function to return the logs
        that will be uploaded to log analytics
        
        Upload-LogAnylyticsData requires the output from Get-MimecastLogs in JSON format, the Log Analytics workspace ID and key and a log type referenced above

    .OUTPUTS
        Name of log type and status code of successful upload to Log Analytics:
        Example: Mimecast_Impersonation_Logs 200
        This output will be each log that has been successfully uploaded
        
    .LINK
        Support and implementation: https://www.itcsecure.com
#>
param($Timer)
# Collecting Azure function global variables and storing values within local script variables. 
# These will be used to generate and connect to respective API's

$accessKey = $ENV:MIMECAST_ACCESS_KEY
$secretKey = $ENV:MIMECAST_SECRET_KEY
$appId = $ENV:MIMECAST_APP_ID
$appKey = $ENV:MIMECAST_APP_KEY
$LAW_ID = $ENV:LAW_ID
$LAW_Key = $ENV:LAW_Key
$storageAccount = $ENV:STORAGE_ACCOUNT_NAME
$SharedAccesskey = $ENV:STORAGE_ACCOUNT_SHARED_KEY
$TableName = $ENV:STORAGE_ACCOUNT_TABLE_NAME
Function Get-TableEntity() {
<#
    The function will connect to the storage space API and collect data from the specified table. The Storage space name shared key and table name are required.
    A Partition key for the table is required if generated. If the function gets past a partition key, the table with that partition key will be returned.
    If not then all tables are returned. The table and partition key will be created before running this script.
#>
    [cmdletbinding()]
          
        param
        (
            [Parameter(Mandatory = $true)]
            [String] $TableName,
            [Parameter(Mandatory = $true)]
            [String] $StorageAccount,
            [Parameter(Mandatory = $true)]
            $AccessKey,
            [Parameter(Mandatory = $false)]
            [String] $PartitionKey
        )
        ##Create storage spaces api Auth Header##
        $Date = (Get-Date).ToUniversalTime().toString('R')
        $hmacsha = New-Object System.Security.Cryptography.HMACSHA256
        $hmacsha.key = [Convert]::FromBase64String($AccessKey)
        $signature = [Convert]::ToBase64String($hmacsha.ComputeHash([Text.Encoding]::UTF8.GetBytes("$Date`n/$StorageAccount/$TableName")))
        $Headers = @{
            "x-ms-date"      = $Date
            Authorization  = "SharedKeyLite " + $StorageAccount + ":" + $signature
            "x-ms-version"   = "2017-04-17"
            Accept        = "application/json;odata=fullmetadata"
        }
        $table_url = "https://$($StorageAccount).table.core.windows.net/$($TableName)"
        try {
            if($PartitionKey){
                try {
                    $item = (Invoke-RestMethod -Method GET -Uri $table_url -Headers $Headers -ContentType application/json).value | Where-Object {$_.PartitionKey -eq $PartitionKey}
                }
                catch {
                    Write-Error "Unable to connect to Table API to list table: $($_.Exception.Message)" `
                        -Exception $($_.Exception) `
                        -Category NotInstalled `
                        -ErrorId $($_.FullyQualifiedErrorId)
                break
                }
                
            }
            else{
                try {
                    $item = (Invoke-RestMethod -Method GET -Uri $table_url -Headers $Headers -ContentType application/json).value
                }
                catch {
                    Write-Error "Unable to connect to Table API to list table: $($_.Exception.Message)" `
                        -Exception $($_.Exception) `
                        -Category NotInstalled `
                        -ErrorId $($_.FullyQualifiedErrorId)
                break
                }
               
            }
        }
        catch {
            Write-Error "Connection to storage account API failed: $($_.Exception.Message)" `
                        -Exception $($_.Exception) `
                        -Category NotInstalled `
                        -ErrorId $($_.FullyQualifiedErrorId)
            break
        }
        return $item
} 
Function Update-TableEntity(){
<#
    This function will update the referenced table within the storage space. 
    The purpose of this is to update the table with the latest mcsiemToken generated from the Mimecast Email log API
    The function requires the Storage account name and shared key, table name, partition and row key and an entity.
    The entity will be added to the payload, along with the partition and row key. This will be converted to JSON and Posted to the storage space.
#>
        [cmdletbinding()]
          
        param
        (
            [Parameter(Mandatory = $true)]
            $TableName,
            [Parameter(Mandatory = $true)]
            $StorageAccount,
            [Parameter(Mandatory = $true)]
            $SharedAccessKey,
            [Parameter(Mandatory = $true)]
            $Entity
        )
        # Table name for existing tables requires name and keys in the below format. 
        # This is passed in to the signature for the auth token along with the API call when updating the table
        $PartitionKey = "P_Key"
        $RowKey = "R_Key"
        $TableName = "$TableName(PartitionKey='$PartitionKey',RowKey='$Rowkey')"
        ##Create storage spaces api Auth Header##
        $Date = (Get-Date).ToUniversalTime().toString('R')
        $hmacsha = New-Object System.Security.Cryptography.HMACSHA256
        $hmacsha.key = [Convert]::FromBase64String($SharedAccessKey)
        $signature = [Convert]::ToBase64String($hmacsha.ComputeHash([Text.Encoding]::UTF8.GetBytes("$Date`n/$StorageAccount/$TableName")))
        $Headers = @{
            "x-ms-date"      = $Date
            Authorization  = "SharedKeyLite " + $StorageAccount + ":" + $signature
            "x-ms-version"   = "2017-04-17"
            Accept        = "application/json;odata=fullmetadata"
        }
        $table_url = "https://$($StorageAccount).table.core.windows.net/$($TableName)"
        $Body = @{
            RowKey       = $RowKey
            PartitionKey = $PartitionKey
            Token      = $Entity
        }
        $Body = $Body | ConvertTo-Json
        try {
            Invoke-RestMethod -Method PUT -Uri $table_url -Headers $Headers -ContentType application/json -Body $Body
        }
        catch {
            Write-Error "Connection to storage account API failed: $($_.Exception.Message)" `
                        -Exception $($_.Exception) `
                        -Category NotInstalled `
                        -ErrorId $($_.FullyQualifiedErrorId)
            break
        }       
}
Function Update-LogAnalyticsData (){
<#
    This function will be used to upload Mimecast log data to the log analytics workspace, via the Azure Monitor API.
    The function requires the log analytics workspace ID and key, a logotype and a JSON object (which will be converted to a byte array)
#>
    [cmdletbinding()]       
        param
        (
            [Parameter(Mandatory = $true)]
            [String] $LAW_WorkspaceID,
            [Parameter(Mandatory = $true)]
            $LAW_Key,
            [Parameter(Mandatory = $true)]
            [String] $LogType,
            [Parameter(Mandatory = $true)]
            $JSON
        )
    ### Generate log analytics auth token ###
    $date = [DateTime]::UtcNow.ToString("r")
    $sha256 = New-Object System.Security.Cryptography.HMACSHA256
    $sha256.Key = [Convert]::FromBase64String($LAW_Key)
    $encodedHash = [Convert]::ToBase64String($sha256.ComputeHash([Text.Encoding]::UTF8.GetBytes("POST`n$($JSON.Length)`napplication/json`nx-ms-date:$($date)`n/api/logs")))
    $authToken = "SharedKey $($LAW_WorkspaceID):$($encodedHash)"

    $headers = @{
        "Authorization" = $authToken;
        "Log-Type" = $LogType;
        "x-ms-date" = $date;
        "time-generated-field" = "";
    }
    ## POST data to log analytics workspace ##
    try {
        $webResponse = Invoke-WebRequest -Uri "https://$($LAW_WorkspaceID).ods.opinsights.azure.com/api/logs?api-version=2016-04-01" -Method Post -ContentType 'application/json' -Headers $headers -Body $JSON
    }
    catch {
        Write-Error "Connection to storage account API failed: $($_.Exception.Message)" `
                    -Exception $($_.Exception) `
                    -Category NotInstalled `
                    -ErrorId $($_.FullyQualifiedErrorId)
        break
    }   
    # This message will be returned as an output after a successful script run
    Return "$($LogType) $($webResponse.StatusCode)"
}
Function Get-MimecastAuthToken () {
<#
    This function will be used to generate an auth token for each API call to Mimecast. 
    The API call will be specific to each API endpoint.
    The function requires the Mimecast app ID, and the access, secret and app keys.
    The URI endpoint for each API will be required as this is ingested when creating the auth token
#>
[cmdletbinding()]
      
    param
    (
        [Parameter(Mandatory = $true)]
        [String] $accessKey,
        [Parameter(Mandatory = $true)]
        [String]$secretKey,
        [Parameter(Mandatory = $true)]
        [String]$appId,
        [Parameter(Mandatory = $true)]
        [String]$appKey,
        [Parameter(Mandatory = $true)]
        [String]$uri
    )
	$hdrDate = (Get-Date).ToUniversalTime().ToString("ddd, dd MMM yyyy HH:mm:ss UTC")
    $requestId = [guid]::NewGuid().guid
 
    #Create the HMAC SHA1 of the Base64 decoded secret key for the Authorization header
    $sha = New-Object System.Security.Cryptography.HMACSHA1
    $sha.key = [Convert]::FromBase64String($secretKey)
    $sig = $sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($hdrDate + ":" + $requestId + ":" + $uri + ":" + $appKey))
    $sig = [Convert]::ToBase64String($sig)
 
    #Create Headers
    $headers = @{"Authorization" = "MC " + $accessKey + ":" + $sig;
                    "x-mc-date" = $hdrDate;
                    "x-mc-app-id" = $appId;
                    "x-mc-req-id" = $requestId;
                    "Content-Type" = "application/json"}

    # The returned header will be used as a parameter when getting logs for each Mimecast API endpoint
    return $headers
}
Function Get-MimecastLogs () {
    <#
        This function connects the logs from each Mimecast api endpoint.
        The logs are collected from the Mimecast api and parsed into a custom PS object which is then returned.
        A switch parameter for $log is required to ensure the correction portion of the script is run. Each endpoint has an option
        Comments on logic for this function will be speciied in the URL portion. Each section run the same script, apart from email logs where comments will be provided.
        Any specific sections unique to the log type will be annotated.
    #>
    [cmdletbinding()]
          
    param
    (
        [Parameter(Mandatory = $true)]
        [ValidateSet("URL", 
            "Impersonation", 
            "Attachment",
            "Email",
            "Audit")]
        $Log
    )
    # creating 2 empty arrays to collect logs and store parsed logs.
    # $logs array used to collect all logs from an api call. purpose for this is to ensure all logs can be collected as the Mimecast api has a hard limit of 500 results to return
    $logs = @()
    # Outlog will store all parsed logs from the $logs array. the $logs array will be looped to parse each log and this information will be stored in $outlog
    $OutLog = @()
    # setting a start date and end date to specify a log collection period for each api call. the collection period will be the last 5 minutes
    $startDate = (Get-Date).AddMinutes(-5).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss+0000")
    $endDate = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss+0000")
    Switch ($Log) {
        "URL" {
            <# 
                Mimecast user account required to have "Monitoring | URL Protection | Read" API permission
                Documentation: https://integrations.mimecast.com/documentation/endpoint-reference/logs-and-statistics/get-ttp-url-logs/
            #>
            # Setting URL collection api endpoint to variable. This will be passed into the Get-MimecastAuthToken and used to get logs from the api
            $uri = "/api/ttp/url/get-logs"
            # Building a dictionary object for the payload, $data stored in array first to ensure the section when coverted to json will contain []
            # Api call will grab malicious logs only
            $data = @([ordered]@{oldestFirst = $false; from = $($startDate); route = "all"; to = $($endDate); scanResult = "malicious"; })
            $postBody = [ordered]@{
                meta = [ordered]@{
                    pagination = [ordered]@{
                        pageSize = 500
                    }
                }
                data = $data
            }
            # Converting the body to json format ready for post request
            $postBody = $postBody | ConvertTo-Json
            $url = "https://eu-api.mimecast.com" + $uri
            # Creating auth token and posting json to api which is used to return all logs
            try {
                $header = Get-MimecastAuthToken -accessKey $accessKey -secretKey $secretKey -appId $appId -appKey $appKey -uri $uri
                $response = Invoke-RestMethod -Method Post -Headers $header -Body $postBody -Uri $url
            }
            catch {
                Write-Error "Mimecast URL log API failed: $($_.Exception.Message)" `
                    -Exception $($_.Exception) `
                    -Category NotInstalled `
                    -ErrorId $($_.FullyQualifiedErrorId)
                break
            }
            <#  Returned api call will check whether the response was sucessful, and the fail section is not populated and data exists within
                    data.clicklogs which is where the log contents is stored
                #>
            if ($response.meta.status -eq 200 -and !$response.fail -and $response.data.clickLogs -and !($response.fail)) {
                <#  Checking to see whether more results have returned. api has page limt of 500, if total size is more than 500
                        a PageToken is returned which will be be used in the next call to grab the remaining logs. 
                        The logs from the initial api call ($response) are stored in the log variable,
                        Then the api call is run continiously, adding all returned logs into $logs,
                        until the PageToken is not returned. This will ensure all logs are collected.
                    #>  
                if ($response.meta.pagination.totalCount -gt $response.meta.pagination.pageSize) {
                    $logs += $response.data.clickLogs
                    while ($response.meta.pagination.next) { 
                        $nextBody = [ordered]@{
                            meta = [ordered]@{
                                pagination = [ordered]@{
                                    pageSize  = 500
                                    pageToken = "$($response.meta.pagination.next)"
                                }
                                        
                            }
                            data = $data
                        }
                        $nextBody = $nextBody | ConvertTo-Json
                        $response = Invoke-RestMethod -Method Post -Headers $header -Body $nextBody -Uri $url
                        $logs += $response.data.clickLogs
                    }     
                }   #if the total count is not greater than the pagesize then the initial returned logs are stored in $logs
                else {
                    $logs += $response.data.clickLogs
    
                }
                # Each log is then parsed, and a PowerShell custom object is created, which then stored in to the $OutLog array
                $logs | ForEach-Object {
                    $Properties = [PSCustomObject]@{
                        "Category"                = $_.category
                        "User Email Address"      = $_.userEmailAddress
                        "From User Email Address" = $_.fromUserEmailAddress
                        "URL"                     = $_.url
                        "User Awareness Action"   = $_.userAwarenessAction
                        "Route"                   = $_.route
                        "Admin Override"          = $_.adminOverride
                        "Date"                    = $_.date
                        "Scan Result"             = $_.scanResult
                        "Action"                  = $_.actions
                        "Definition"              = $_.ttpDefinition
                        "User Override"           = $_.userOverride
                        "emailPartsDescription"   = $_.emailPartsDescription
                        "Creation Method"         = $_.creationMethod
                        "sending IP Address"      = $_.sendingIp
                        "Subject"                 = $_.subject
                    }
                    $OutLog += $Properties
                }  # The OutLog is returned once the function has completed
                return $OutLog     
            }
            # If the api call failed or no results were returned, the function will return nothing
            else { return $null }
        }
        "Impersonation" {
            <#
                Mimecast user account required to have "Monitoring | Impersonation Protection | Read" API permission
                Documentation: https://integrations.mimecast.com/documentation/endpoint-reference/logs-and-statistics/get-ttp-impersonation-protect-logs/
            #>
            $uri = "/api/ttp/impersonation/get-logs"
            # api call will only return results which were tagged as malicious. Expectation is 0 to few results will be returned for each 5 minute run.
            $data = @([ordered]@{oldestFirst = $false; taggedMalicious = $true; searchField = $null; identifiers = $null; query = $null; from = $($startDate); to = $($endDate); actions = $null; })
            $postBody = [ordered]@{
                meta = [ordered]@{
                    pagination = [ordered]@{
                        pageSize = 500
                    }
                }
                data = $data
            }
            $postBody = $postBody | ConvertTo-Json
            $url = "https://eu-api.mimecast.com" + $uri
            try {
                $header = Get-MimecastAuthToken -accessKey $accessKey -secretKey $secretKey -appId $appId -appKey $appKey -uri $uri
                $response = Invoke-RestMethod -Method Post -Headers $header -Body $postBody -Uri $url
            }
            catch {
                Write-Error "Mimecast Impersonation log API failed: $($_.Exception.Message)" `
                    -Exception $($_.Exception) `
                    -Category NotInstalled `
                    -ErrorId $($_.FullyQualifiedErrorId)
                break 
            }
            if ($response.meta.status -eq 200 -and !($response.fail) -and $response.data.resultCount -ne 0) {
                if ($response.meta.pagination.totalCount -gt $response.meta.pagination.pageSize) {
                    $logs += $response.data.impersonationLogs
                    while ($response.meta.pagination.next) {
                        $nextBody = [ordered]@{
                            meta = [ordered]@{
                                pagination = [ordered]@{
                                    pageSize  = 500
                                    pageToken = "$($response.meta.pagination.next)"
                                }
                            }
                            data = $data
                        }
                        $nextBody = $nextBody | ConvertTo-Json
                        $response = Invoke-RestMethod -Method Post -Headers $header -Body $nextBody -Uri $url
                        $logs += $response.data.impersonationLogs
                    }
                }
                else {
                    $logs += $response.data.impersonationLogs
                }
                $logs | ForEach-Object {
                    $Properties = [PSCustomObject]@{
                        "ID"                    = $_.id
                        "Sender Address"        = $_.senderAddress
                        "Recipient Address"     = $_.recipientAddress
                        "Subject"               = $_.Subject
                        "Definition"            = $_.definition
                        "Hits"                  = $_.hits
                        "Identifiers"           = $_.identifiers
                        "Action"                = $_.action
                        "Tagged External"       = $_.taggedExternal
                        "Tagged Malicious"      = $_.taggedMalicious
                        "Sender IP Address"     = $_.senderIpAddress
                        "Date"                  = $_.eventTime
                        "Impersonation Results" = $_.impersonationResults
                        "Message ID"            = $_.messageId
                    }
                    $OutLog += $Properties
                }
                return $OutLog       
            }
            else { return $null }
        }
        "Attachment" {
            <#
                Mimecast user account required to have "Monitoring | Attachment Protection | Read" API permission
                Documentation: https://integrations.mimecast.com/documentation/endpoint-reference/logs-and-statistics/get-ttp-attachment-protection-logs/
            #>
            $uri = "/api/ttp/attachment/get-logs"
            $data = @([ordered]@{oldestFirst = $false; from = $($startDate); route = "all"; to = $($endDate); scanResult = "all"; })
            $postBody = @{
                meta = @{
                    pagination = @{
                        pageSize = 500
                    }
                }
                data = $data
            }
            $postBody = $postBody | ConvertTo-Json
            $url = "https://eu-api.mimecast.com" + $uri
            try {
                $header = Get-MimecastAuthToken -accessKey $accessKey -secretKey $secretKey -appId $appId -appKey $appKey -uri $uri
                $response = Invoke-RestMethod -Method Post -Headers $header -Body $postBody -Uri $url
            }
            catch {
                Write-Error "Mimecast Attachment log API failed: $($_.Exception.Message)" `
                    -Exception $($_.Exception) `
                    -Category NotInstalled `
                    -ErrorId $($_.FullyQualifiedErrorId)
                break
            }
            if ($response.meta.status -eq 200 -and $response.data.attachmentLogs -and !($response.fail)) {
                if ($response.meta.pagination.totalCount -gt $response.meta.pagination.pageSize) {
                    $logs += $response.data.attachmentLogs
                    while ($response.meta.pagination.next) {
                        $nextBody = @{
                            meta = @{
                                pagination = @{
                                    pageSize  = 500
                                    pageToken = "$($response.meta.pagination.next)"
                                }
                            }
                            data = $data
                        }
                        $nextBody = $nextBody | ConvertTo-Json
                        $response = Invoke-RestMethod -Method Post -Headers $header -Body $nextBody -Uri $url
                        $logs += $response.data.attachmentLogs
                    }
                }
                else {
                    $logs += $response.data.attachmentLogs
    
                }
                <#  Attachment logs return all results, afe, malicious, timeout, error, unsafe. 
                    This cannot be filtered within the api call (unless only 1 result is required to be returned)
                    During the log parsing a check will be made to ensure only logs which are not deemed safe will be returned
                #>
                $logs | ForEach-Object {
                    if ($_.result -ne "safe") {
                        $Properties = [PSCustomObject]@{
                            "Result"            = $_.result
                            "Date"              = ([DateTime]$_.date).ToString("dd/MM/yyyy HH:mm:ss")
                            "Sender Address"    = $_.senderAddress
                            "File Name"         = $_.fileName
                            "File Type"         = $_.filetype
                            "File Hash"         = $_.fileHash
                            "Action Triggered"  = $_.actionTriggered
                            "Route"             = $_.route
                            "Details"           = $_.details
                            "Recipient Address" = $_.recipientAddress
                            "Subject"           = $_.subject
                            "Defninition"       = $_.definition
                            "Message ID"        = $_.messageId
                            
                        }
                        $OutLog += $Properties
                    }
                }
                return $OutLog
            }
            else { return $null }
            
        }
        "Email" {
            <#
                Mimecast user account required to have "Gateway | Tracking | Read" API permission. Enhanced Logging must also be enabled.
                Documentation: https://integrations.mimecast.com/documentation/endpoint-reference/logs-and-statistics/get-siem-logs/
                This api call returned several formatted emial logs, see: https://integrations.mimecast.com/documentation/tutorials/understanding-siem-logs/
                This means notible gaps will be present for each log during parsing, the api call does not return information that can be used to easily`
                identify which type of email log gets returned. 
                All logs are processed thgrough the same parsing process and logged into the same log analytics custom table.
            #>
            $uri = "/api/audit/get-siem-logs"
            # Getting the SIEM token from last script run
            $mcSIEMToken = Get-TableEntity -PartitionKey $PartitionKey -TableName $TableName -StorageAccount $storageAccount -AccessKey $SharedAccesskey
            # if a token exists, this is passed into the data field
            if ($mcSIEMToken.token) {
                $token = $mcSIEMToken.token
            }
            else {
                $token = $null
    
            }
            # data to post for the payload, the token value, is present will be passed, if no result is present, the token will be null
            # The SIEM token is used to return only new results which were not present since the last api call.
            $data = @([ordered]@{type = "MTA"; token = $token; fileFormat = "json"; compress = $false; }) 
            $postBody = [ordered]@{data = $data } | ConvertTo-Json      
            $url = "https://eu-api.mimecast.com" + $uri
            try {
                $header = Get-MimecastAuthToken -accessKey $accessKey -secretKey $secretKey -appId $appId -appKey $appKey -uri $uri
                # Response headers are required to grab the mcSIEMToken value. PowerShell 7.0 is required to run the -ResponseHeadersVariable parameter
                $response = Invoke-RestMethod -Method Post -Headers $header -Body $postBody -Uri $url -ResponseHeadersVariable 'ResponseHeader'
                $Token = $($ResponseHeader.'mc-siem-token')
                # Updating the storage spaces table with the latest siemtoken 
                Update-TableEntity -SharedAccessKey $SharedaccessKey -StorageAccount $storageAccount -Entity $Token -TableName $TableName
            }
            catch {
                Write-Error "Mimecast Email log API failed: $($_.Exception.Message)" `
                    -Exception $($_.Exception) `
                    -Category NotInstalled `
                    -ErrorId $($_.FullyQualifiedErrorId)
                break
            }
            # If a response header is returned, The data is parsed, as mentioned this api call returns several email logs (see docs) and each parameter`
            # is referenced in the below object. This ensures all data is captured from each log however fequent gaps in each header appears
            if ($ResponseHeader) {
                $response.data | ForEach-Object {
                    $Properties = [PSCustomObject]@{
                        "AccountCode"           = $($_.acc)
                        "AccountCodeID"         = $_.aCode
                        "Act"                   = $_.Act
                        "Attempt Count"         = $_.Attempt
                        "Cipher"                = $_.Cphr
                        "Date"                  = $_.datetime
                        "Delivered"             = $_.Delivered
                        "Direction"             = $_.dir
                        "MessageError"          = $_.Error
                        "SenderIP"              = $_.IP
                        "MessageID"             = $_.MsgId
                        "Recipient"             = $_.Rcpt
                        "RejectCode"            = $_.RejCode
                        "RejectInfo"            = $_.RejInfo
                        "RejectType"            = $_.RejType
                        "Route"                 = $_.Route
                        "Sender"                = $_.Sender
                        "SenderHeader"          = $_.headerFrom
                        "SpamInfo"              = $_.Spaminfo
                        "SpamLimit"             = $_.SpamLimit
                        "SpamProcessing_Detail" = $_.SpamProcessingDetail
                        "SpamScore"             = $_.SpamScore
                        "Subject"               = $_.Subject
                        "TLS_Version"           = $_.TlsVer
                        "Virus"                 = $_.Virus
                    }
                    $OutLog += $Properties
                }
                return $OutLog
            }
            else { return $null }
        }
        "Audit" {
            <#
                Mimecast user account required to have "Account | Logs | Read" API permission
                Documentation: https://integrations.mimecast.com/documentation/endpoint-reference/logs-and-statistics/get-audit-events/
            #>
            $uri = "/api/audit/get-audit-events"
            # api call will return all categories, ensuring all audit logs are collected
            $data = @([ordered]@{query = $null; endDateTime = $($endDate); categories = $null; startDateTime = $($startDate);
                })
            $postBody = @{
                meta = @{
                    pagination = @{
                        pageSize = 500
                    }
                }
                data = $data
            }
            $postBody = $postBody | ConvertTo-Json
            $url = "https://eu-api.mimecast.com" + $uri
            try {
                $header = Get-MimecastAuthToken -accessKey $accessKey -secretKey $secretKey -appId $appId -appKey $appKey -uri $uri
                $response = Invoke-RestMethod -Method Post -Headers $header -Body $postBody -Uri $url
            }
            catch {
                Write-Error "Mimecast Audit log API failed: $($_.Exception.Message)" `
                    -Exception $($_.Exception) `
                    -Category NotInstalled `
                    -ErrorId $($_.FullyQualifiedErrorId)
                break 
            }
            if ($response.meta.status -eq 200 -and $response.data -and !($response.fail)) {
                if ($response.meta.pagination.next) {
                    $logs += $response.data
                    while ($response.meta.pagination.next) {
                        $nextBody = @{
                            meta = @{
                                pagination = @{
                                    pageSize  = 500
                                    pageToken = "$($response.meta.pagination.next)"
                                }
                            }
                            data = $data
                        }
                        $nextBody = $nextBody | ConvertTo-Json
                        $response = Invoke-RestMethod -Method Post -Headers $header -Body $nextBody -Uri $url
                        $logs += $response.data
                    }
                }
                else {
                    $logs += $response.data
    
                }
                $logs | ForEach-Object {
                    if ($_.eventinfo -match "Failed authentication for" -or $_.eventinfo -match "Successful authentication for") {
                        $infoTrim = $_.eventInfo.Split(',').trim( )
                        $eventInfo = [ordered]@{
                            Message     = $infoTrim[0];
                            Date        = $infoTrim[1].Substring($infoTrim[1].IndexOf(' ') + 1);
                            Time        = $infoTrim[2].Substring($infoTrim[2].IndexOf(' ') + 1);
                            IP          = $infoTrim[3].Substring($infoTrim[3].IndexOf(' ') + 1);
                            Application = $infoTrim[4].Substring($infoTrim[4].IndexOf(' ') + 1)
    
                        }
                    }
                    else {
                        $eventInfo = [ordered]@{
                            Message = $_.eventInfo;
                        }
                    }
                    $Properties = [PSCustomObject]@{
                        "Audit Type" = $_.auditType
                        "User"       = $_.user
                        "Category"   = $_.category
                        "Event Info" = $eventInfo
                        "Date"       = ([DateTime]$_.eventtime).ToString("dd/MM/yyyy HH:mm:ss")
                        "ID"         = $_.id
                    }
                    $OutLog += $Properties
                }
                return $OutLog
    
            }
            else { return $null }
        }
    }
}
##################################################################################
<#
    The main portion of the script. This section will process and upload the logs for each log source.
    Additional checks for the correct version of PowerShell and whether necessary data (for API connections) is populated
    Each log request will return the last 5 minutes of logs. If there were no results returned, then the script will not execute
    a request to the log analytics workspace.
    The logs are stored within a variable, which will return a PowerShell object array
    That array is then converted to JSON and passed into the request to upload to the log analytics workspace. The JSON object is converted to a byte array before being posted.
    Please comment out any block that is not required to be uploaded into Log analytics
#>
        #Checking for PowerShell version 7 and Full language
        if($PSVersionTable.GitCommitId -lt 7.0.0){
            Write-Error -Exception $([exception]::new("PowerShell configuration error: This script requires Powershell version 7.0.0 or higher, `"$($PSVersionTable.GitCommitId)`" has been detected.")) -Category InvalidType 
            break
        }
        if ($ExecutionContext.SessionState.LanguageMode -ne "FullLanguage") {
            Write-Error -Exception $([exception]::new("PowerShell configuration error: This script requires full PowerShell language mode, `"$($ExecutionContext.SessionState.LanguageMode)`" has been detected.")) -Category InvalidType 
            break
        }
        #Checking for Mimecast AppID, App Key, Access Key and Secrey Key Values
        if (!$accessKey -or !$appId -or !$secretKey -or !$appKey -or !$LAW_ID -or !$LAW_Key) {
            Write-Error -Exception $([exception]::new("Script Requires string values for Mimecast App ID, Access Key, Secret Key and App Key, and Log Analytics Worksapce ID and Key to continue")) -Category InvalidType
            break
        }
        #Getting latest Mimecast logs and storing them into a PowerShell custom object read for uploading to log analytics
        ## URL Logs ##
        $URLLogs = Get-MimecastLogs -log URL
        if($URLLogs.Count -gt 0){
            $URLLogs = $URLLogs | ConvertTo-Json
            Update-LogAnalyticsData -JSON ([System.Text.Encoding]::UTF8.GetBytes($URLLogs)) -LAW_WorkspaceID $LAW_ID -LAW_Key $LAW_Key -LogType "Mimecast_URL_Logs"
        }
        else {Write-Host "0 URL Logs collected during this run"}
        ##
        ## Attachment Logs ##
         $AttachmentLogs = Get-MimecastLogs -Log Attachment
        if($AttachmentLogs.count -gt 0){
            $AttachmentLogs = $AttachmentLogs | ConvertTo-Json
            Update-LogAnalyticsData -JSON ([System.Text.Encoding]::UTF8.GetBytes($AttachmentLogs)) -LAW_WorkspaceID $LAW_ID -LAW_Key $LAW_Key -LogType "Mimecast_Attachment_Logs"
        }
        else {Write-Host "0 Attachment Logs collected during this run"}
        ##
        ## Impersonation Logs ##
        $ImpersonationLogs = Get-MimecastLogs -Log Impersonation
        if($ImpersonationLogs.count -gt 0){
            $ImpersonationLogs = $ImpersonationLogs | ConvertTo-Json
            Update-LogAnalyticsData -JSON ([System.Text.Encoding]::UTF8.GetBytes($ImpersonationLogs)) -LAW_WorkspaceID $LAW_ID -LAW_Key $LAW_Key -LogType "Mimecast_Impersonation_Logs"
        }
        else {Write-Host "0 Impersonation Logs collected during this run"}
        ##
        ## Audit Logs ##
        $AuditLogs = Get-MimecastLogs -Log Audit
        if($AuditLogs.count -gt 0){
            $AuditLogs = $AuditLogs | ConvertTo-Json
            Update-LogAnalyticsData -JSON ([System.Text.Encoding]::UTF8.GetBytes($AuditLogs)) -LAW_WorkspaceID $LAW_ID -LAW_Key $LAW_Key -LogType "Mimecast_Audit_Logs"
        }
        else {Write-Host "0 Audit Logs collected during this run"}
        ##
        ## Email Logs ##
        <#
         Email logs require an additional check. When running Get-MimecastLogs -Log Email an empty result is returned in position 0 within the array.
         the below if statement checks for that entry and removes it ensuring only actual data will be processed, removing the empty value
         Error only occurs when running Update-TableEntity. 
        #>
        $EmailLogs = @()
        Get-MimecastLogs -Log Email | ForEach-Object {
            if($_ -ne "" ){
                $EmailLogs += $_
            }
        }
        if($EmailLogs.count -gt 0 -and $SharedAccesskey){
            $EmailLogs = $EmailLogs | ConvertTo-Json
            Update-LogAnalyticsData -JSON ([System.Text.Encoding]::UTF8.GetBytes($EmailLogs)) -LAW_WorkspaceID $LAW_ID -LAW_Key $LAW_Key -LogType "Mimecast_Email_Logs"
        }
        else {Write-Host "0 Email Logs collected during this run"}
        ##